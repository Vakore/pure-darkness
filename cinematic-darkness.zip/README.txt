Turn custom colors on in Optifine settings.

vanilla-lightmap by Nixel: https://www.planetminecraft.com/texture-pack/for-resource-pack-developers-vanilla-overworld-lightmap-recreation/